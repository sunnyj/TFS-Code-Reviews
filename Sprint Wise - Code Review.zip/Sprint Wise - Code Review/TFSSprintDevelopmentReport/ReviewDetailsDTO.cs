﻿using System.Collections.Generic;
using System.Linq;
using static TFSSprintDevelopmentReport.CodeReviewForm;

namespace Utility
{
    public class ReviewDetailsDTO
    {
        public List<CodeReviewComment> FindingDetails { get; set; }

        public string SprintNumber { get; set; }
        public string Team { get; set; }
    }
}