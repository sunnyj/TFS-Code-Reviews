﻿using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Utility;
using Microsoft.TeamFoundation.Discussion.Client;

namespace TFSSprintDevelopmentReport
{
    public partial class CodeReviewForm : Form
    {
        #region Declarations
        static string toEmail = ConfigurationManager.AppSettings["toEmail"];
        static string sprintNumber = ConfigurationManager.AppSettings["sprintNumber"];
        static string team = ConfigurationManager.AppSettings["team"];
        static string project = ConfigurationManager.AppSettings["project"];
        static string areaPath = ConfigurationManager.AppSettings["areaPath"];
        static string tfsUrl = ConfigurationManager.AppSettings["tfsUrl"];
        static string userName = ConfigurationManager.AppSettings["userName"];
        static string password = ConfigurationManager.AppSettings["password"];
        static string domain = ConfigurationManager.AppSettings["domain"];
        static string currentSprint = ConfigurationManager.AppSettings["currentSprint"];
        static string configIterationPath = ConfigurationManager.AppSettings["iterationPath"];
        List<FindingDTO> searchReport = new List<FindingDTO>();
        List<BlankTaskDTO> blankTaskReport = new List<BlankTaskDTO>();
        CodeReviewCommentList finalReviewComments = new CodeReviewCommentList();
        #endregion

        public CodeReviewForm()
        {
            InitializeComponent();
        }

        #region Click Events
        private void id_Go_Click(object sender, EventArgs e)
        {
            // Get Single sprint data
            id_Current.Text = txt_Iteration.Text;
            GetDetails(txt_Iteration.Text);

            // Get comma separated multiple sprints data
            //GetAndSendReviewComments();
        }

        private void id_Send_Click(object sender, EventArgs e)
        {
            SendReviewComments();
        }


        #endregion

        #region [Get Details]
        private void GetAndSendReviewComments()
        {
            string[] values = txt_Iteration.Text.Split(',');
            for (int i = 0; i < values.Length; i++)
            {
                // SET Current sprint
                id_Current.Text = values[i];
                // Get the Data
                GetDetails(values[i].Trim());
                //Send Email
                SendReviewComments();
            }

        }

        public void GetDetails(string iterationPath)
        {
            progressBar1.Visible = true;
            dataGridView1.Visible = false;
            var tfs = GetTFSProject();
            try
            {
                var workItemStore = tfs.GetService<WorkItemStore>();
                var queryText = @"SELECT [System.Id], [Closed Status],
                                    [System.Title], 
                                    [System.AssignedTo], 
                                    [System.State], 
                                    [System.CreatedBy],
                                    [Microsoft.VSTS.Scheduling.RemainingWork]
                                FROM WorkItems 
                                WHERE [System.TeamProject] = @project 
                                AND [System.IterationPath] = @iterationPath
                                AND [System.AreaPath] = @areaPath
                                AND [Closed Status] NOT IN ('Declined','Looks Good','Removed')
                                AND [System.WorkItemType] IN('Code Review Request')";


                var workItems = checkPBIExists(tfs, iterationPath, queryText);


                var result = new List<TaskModel>();
                if (workItems != null)
                {
                    finalReviewComments.Reviews = new List<CodeReviewComment>();
                    progressBar1.Minimum = 0;
                    progressBar1.Maximum = workItems.Count;
                    var count = 0;
                    foreach (WorkItem workItem in workItems)
                    {
                        progressBar1.Value = count++;
                        // Get review comments
                        finalReviewComments.Reviews.AddRange(GetCodeReviewComments(workItem));
                    }

                    dataGridView1.DataSource = finalReviewComments.Reviews.ToList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("There is some problem in connecting to TFS. Error details:", ex.Message);
                //throw;
            }
            progressBar1.Visible = false;
            dataGridView1.Visible = true;

        }

        public List<CodeReviewComment> GetCodeReviewComments(WorkItem workItem)
        {
            List<CodeReviewComment> comments = new List<CodeReviewComment>();

            Uri uri = new Uri(tfsUrl);
            TeamFoundationDiscussionService service = new TeamFoundationDiscussionService();
            service.Initialize(new TfsTeamProjectCollection(uri));
            IDiscussionManager discussionManager = service.CreateDiscussionManager();

            IAsyncResult result = discussionManager.BeginQueryByCodeReviewRequest(workItem.Id, QueryStoreOptions.ServerAndLocal, new AsyncCallback(CallCompletedCallback), null);
            var output = discussionManager.EndQueryByCodeReviewRequest(result);
            string[] severityStandards = { "Low", "low", "High", "high", "Medium", "medium" };

            foreach (DiscussionThread thread in output)
            {
                if (thread.RootComment != null && thread.RootComment.Content.Contains("^"))
                {
                    var commentSplits = thread.RootComment.Content.Split('^');
                    CodeReviewComment comment = new CodeReviewComment();
                    comment.Author = thread.RootComment.Author.DisplayName;
                    comment.Comment = thread.RootComment.Content;
                    comment.PublishDate = thread.RootComment.PublishedDate.ToShortDateString();
                    comment.ItemName = thread.ItemPath;
                    comment.Severity = commentSplits[commentSplits.Length - 1];
                    comment.ReviewType = commentSplits[commentSplits.Length - 2];
                    comment.RequestedBy = workItem.CreatedBy;
                    comment.CreatedDate = workItem.CreatedDate;
                    comment.SprintNumber = workItem.IterationPath;

                    if (severityStandards.Contains(comment.Severity))
                    {
                        comments.Add(comment);
                    }
                }
            }

            return comments;
        }

        private static TfsTeamProjectCollection GetTFSProject()
        {
            NetworkCredential cred = new NetworkCredential(userName, password, domain);
            Uri tfsUri = new Uri(tfsUrl);
            var tfs = new TfsTeamProjectCollection(tfsUri, cred);
            return tfs;
        }
        private static WorkItemCollection checkPBIExists(TfsTeamProjectCollection tfs, string iterationPath, string queryText)
        {
            try
            {
                WorkItemStore wiStore = new WorkItemStore(tfs);

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("project", project);
                parameters.Add("iterationPath", iterationPath);
                parameters.Add("areaPath", areaPath);
                parameters.Add("currentSprint", currentSprint);

                var query = new Query(wiStore, queryText, parameters);
                var workItem = query.RunQuery();

                return workItem;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in fetching, error:- ", ex.Message);
                return null;
            }
        }

        #endregion  

        #region [Send Email]

        private void SendReviewComments()
        {
            if (finalReviewComments.Reviews.Count > 0)
            {
                try
                {
                    // Open Tasks details.
                    SendReviewEmail(finalReviewComments.Reviews);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Not able to send email, error:- ", ex.Message);
                }
            }
            else
            {
                MessageBox.Show("No data available !!");
            }
        }

        private void SendReviewEmail(List<CodeReviewComment> report)
        {
            var sprintDetails = new ReviewDetailsDTO()
            {
                FindingDetails = report,
                SprintNumber = id_Current.Text ?? txt_Iteration.Text,
                Team = txt_Iteration.Text       // Can be changes as per project need
            };

            var emailSender = new EmailSender();
            var xsltfilepath = @"CodeReviewReport.xslt";
            emailSender.SendEmail(Helper.GetEmailBody(sprintDetails, xsltfilepath));

            MessageBox.Show("Email sent !!!", "Email status", MessageBoxButtons.OK);
        }

        #endregion

        private void CodeReviewForm_Load(object sender, EventArgs e)
        {
            txt_Iteration.Text = configIterationPath;
        }
        static void CallCompletedCallback(IAsyncResult result)
        {
            // Handle error conditions here
        }

        #region models

        //private class ReviewDetailsDTO
        //{
        //    public List<CodeReviewComment> FindingDetails { get; set; }

        //    public string SprintNumber { get; set; }
        //}
        private class TaskModel : BlankTaskModel
        {
            public string AssignedTo { get; set; }
            public string SprintNumber { get; set; }
        }

        private class BlankTaskModel
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string State { get; set; }
            public double RemainingWork { get; set; }
            public string CreatedBy { get; set; }
            public string ChangedBy { get; set; }
        }
        public class CodeReviewComment
        {
            public string Author { get; set; }
            public string Comment { get; set; }
            public string PublishDate { get; set; }
            public string ItemName { get; set; }
            public string ReviewType { get; set; }
            public string Severity { get; set; }
            public string RequestedBy { get; set; }
            public DateTime CreatedDate { get; set; }
            public string SprintNumber { get; set; }
        }

        public class CodeReviewComments
        {
            public string Author { get; set; }
            public string Comment { get; set; }
            public string PublishDate { get; set; }
            public string ItemName { get; set; }
            public string ReviewType { get; set; }
            public string Severity { get; set; }
            public string RequestedBy { get; set; }
            public DateTime CreatedDate { get; set; }
            public string SprintNumber { get; set; }
        }
        public class CodeReviewCommentList
        {
            public List<CodeReviewComment> Reviews { get; set; }
        }



        #endregion

    }
}