﻿using Utility;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TFSSprintDevelopmentReport
{
    static class Program
    {
        static string iterationPath = ConfigurationManager.AppSettings["iterationPath"];
        static string team = ConfigurationManager.AppSettings["team"];
        static string project = ConfigurationManager.AppSettings["project"];
        static string tfsUrl = ConfigurationManager.AppSettings["tfsUrl"];
        static string userName = ConfigurationManager.AppSettings["userName"];
        static string password = ConfigurationManager.AppSettings["password"];
        static string domain = ConfigurationManager.AppSettings["domain"];
        static string sprintNumber = ConfigurationManager.AppSettings["sprintNumber"];

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new UserDetails());
            Application.Run(new CodeReviewForm());

        }

    }
}
