﻿namespace TFSSprintDevelopmentReport
{
    public class FindingDTO
    {
        public string UserName { get; set; }
        public int TasksCount { get; set; }
        public double RemainingWork { get; set; }
        public string Status { get; set; }
    }
}