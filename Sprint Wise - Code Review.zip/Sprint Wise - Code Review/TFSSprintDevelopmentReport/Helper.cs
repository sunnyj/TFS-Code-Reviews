﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Reflection;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.Serialization;
using System.IO;
using TFSSprintDevelopmentReport;

namespace Utility
{
    static class Helper
    {
        public static string GetEmailBody(SprintDetailsDTO sprintDetails, string xsltfilepath)
        {
            return TransformXsltToXml(sprintDetails, xsltfilepath);
        }

        public static string GetEmailBody(BlankTaskDetailsDTO sprintDetails, string xsltfilepath)
        {
            return TransformXsltToXml(sprintDetails, xsltfilepath);
        }

        public static string GetEmailBody(ReviewDetailsDTO sprintDetails, string xsltfilepath)
        {
            return TransformXsltToXml(sprintDetails, xsltfilepath);
        }

        /// <summary>
        /// Get XML from Xslt file
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="bodyDetails"></param>
        /// <param name="xsltfilepath"></param>
        /// <returns></returns>
        public static string TransformXsltToXml<T>(T bodyDetails, string xsltfilepath)
        {
            var memoryStream = new MemoryStream();

            string xmlData = string.Empty;
            try
            {
                XmlSerializer xserialization = new XmlSerializer(bodyDetails.GetType());
                string xmlString;
                using (StringWriter stringWriter = new StringWriter())
                {
                    xserialization.Serialize(stringWriter, bodyDetails);
                    xmlString = stringWriter.ToString();
                }

                var xd = new XmlDocument();
                xd.LoadXml(xmlString);

                var xslt = new System.Xml.Xsl.XslCompiledTransform();
                xslt.Load(xsltfilepath);

                xslt.Transform(xd, null, memoryStream);
                memoryStream.Position = 0;
                var sr = new StreamReader(memoryStream);
                xmlData = sr.ReadToEnd();
            }
            finally
            {
                memoryStream.Close();
            }
            return xmlData;
        }
    }

}
