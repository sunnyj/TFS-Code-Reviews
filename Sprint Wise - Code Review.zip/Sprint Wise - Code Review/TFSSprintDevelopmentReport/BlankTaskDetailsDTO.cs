﻿using System.Collections.Generic;

namespace TFSSprintDevelopmentReport
{
    public class BlankTaskDetailsDTO
    {
        public List<BlankTaskDTO> FindingDetails { get; set; }

        public string SprintNumber { get; set; }
        public string Team { get; set; }
    }
}