﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Configuration;
using System.IO;
using System.Net;
using System.Data;
using Utility;

public class EmailSender
{
    public const char EMAIL_SEPARATOR = ';';
    public const string FROM_EMAIL = "fromEmail";
    public const string TO_EMAIL = "toEmail";
    public const string CC_EMAIL = "ccEmail";
    public const string SUPPORT_EMAIL = "supportEmail";
    public const string EASYPURCHASE = "EasyPurchase";
    public const string EMAIL_SUBJECT = " Code Review Finding Details -";

    /// <summary>
    /// Send Email
    /// </summary>
    /// <param name="reviewDetails"></param>
    public void SendEmail(string reviewDetails)
    {
        using (MailMessage message = new MailMessage())
        {
            SetMessageDetails(message, reviewDetails, false);
            using (SmtpClient client = new SmtpClient())
            {
                client.Send(message);
            }
        }
    }

    /// <summary>
    /// Set Message Details
    /// </summary>
    /// <param name="message"></param>
    /// <param name="reviewDetails"></param>
    public void SetMessageDetails(MailMessage message, string reviewDetails, bool errorExist)
    {
        string FromMail = ConfigurationManager.AppSettings[FROM_EMAIL], subject = string.Empty;
        string ToMail = string.Empty;


        ToMail = ConfigurationManager.AppSettings[TO_EMAIL];
        subject = "TFS Sprint tasks status report";

        string CcMail = ConfigurationManager.AppSettings[CC_EMAIL];
        message.From = new MailAddress(FromMail, "noreply@Test.co.in");

        if (!string.IsNullOrEmpty(ToMail))
        {
            var toList = ToMail.Split(EMAIL_SEPARATOR).ToList();
            foreach (string email in toList)
            {
                if (email.Trim() != string.Empty)
                {
                    message.To.Add(new MailAddress(email));
                }
            }
        }

        if (!string.IsNullOrEmpty(CcMail))
        {
            var ccList = CcMail.Split(EMAIL_SEPARATOR).ToList();
            foreach (string email in ccList)
            {
                if (email.Trim() != string.Empty)
                {
                    message.CC.Add(new MailAddress(email));
                }
            }
        }

        message.Subject = subject + " - " + DateTime.Now.ToShortDateString();
        message.Body = reviewDetails;
        message.IsBodyHtml = true;
    }

    /// <summary>
    /// Send Email
    /// </summary>
    /// <param name="reviewDetails"></param>
    public void SendErrorEmail(Exception exc, string solution)
    {
        using (MailMessage message = new MailMessage())
        {
            SetMessageDetails(message, exc.Message + " \n" + exc.StackTrace.ToString(), true);
            using (SmtpClient client = new SmtpClient())
            {
                client.Send(message);
            }
        }
    }
}
