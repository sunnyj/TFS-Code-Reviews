﻿using System.Collections.Generic;

namespace TFSSprintDevelopmentReport
{
    public class SprintDetailsDTO
    {
        public List<FindingDTO> FindingDetails { get; set; }

        public string SprintNumber { get; set; }
    }
}